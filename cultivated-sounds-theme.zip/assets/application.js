// Application JS
console.log('Cultivated Sounds Theme Loaded');
